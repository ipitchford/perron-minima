# Referee computational checks — 28 September 2026

Reviewed: Constructive resolvent ordering and weighted Perron minima, research draft 0.1 (27 September 2026).

## Input identification

Archive: resolvent_extensions_v0_1(1).zip
SHA-256: 075d2618f7e86d7be211717222c351ba77d7df91ccbe77fef85d99bde923ff6f

## Submitted replay

`python replay.py --full` was run in the extracted submission. All eight jobs passed; all 40 manifested files matched before and after. The outer runner returned code zero. Its stdout, stderr and timing receipt are included. These tests are the author's supplied checks, not an independent implementation.

## Independent implementation

`independent_checks.py` imports no submitted code. Run with Python, NumPy, SciPy and SymPy. The review environment used Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0 and SymPy 1.14.0.

It enumerates all 32,768 labelled tournaments of order six at each of t=0.5 and t=1, compares with all 720 labelled Brualdi–Li copies, and implements the alternating repair separately for all 2,640 nearly regular cases at each parameter. It checks 24 exact weighted characteristic polynomials and three 125-point continuous-box grids. The output records every failure count and scope. The weighted characteristic polynomials are exact rational computations. Eigenvalue and resolvent computations in the tournament and grid checks use floating point and a tolerance; they do not constitute interval certificates or a proof in arbitrary dimension.

## Important observations

At n=6, t=0.5 the coefficient is about 0.0000243465073, whereas the smallest computed non-Brualdi–Li deficit is about 0.001392082825. Their ratio is 57.18, greater than the trivial edge-distance bound 15. At t=1 the analogous ratio is 411.34. The independent repair example returns distance four although a distance-one Brualdi–Li copy exists; the manuscript explicitly does not promise nearest recovery.

Section 3 needs to exclude (n,t)=(2,1) from its strict resolvent-admissibility assertion. At that endpoint lambda0=1=n-1 and u=1, so the asserted strict inequality fails. The main stability theorem already states n>=4 and is not contradicted.

## Limits

This package contains no proof-assistant verification, exhaustive literature clearance or external specialist endorsement. The manuscript and third-party journal PDFs are not redistributed here. Finite numerical agreement is corroboration only. Runtime values may differ between runs.

"""Independent referee checks. Does not import the submitted code.
Finite floating-point checks corroborate, and do not certify, general theorems.
"""
from itertools import combinations, permutations, product
import json, time
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.optimize import brentq

start=time.time()
out={"scope":"Independent finite numerical and rational checks; no submitted code imported"}

def skew(n, bits):
    S=np.zeros((n,n))
    for k,(i,j) in enumerate(combinations(range(n),2)):
        S[i,j]=1 if ((bits>>k)&1) else -1
        S[j,i]=-S[i,j]
    return S

def encode(S):
    return sum((int(S[i,j]>0)<<k) for k,(i,j) in enumerate(combinations(range(len(S)),2)))

def rho(A):
    return float(np.max(np.linalg.eigvals(A).real))

# All labelled six-vertex tournaments: a full search, not random sampling.
n=6
Q=np.triu(np.ones((n,n)),1);Q-=Q.T
r=np.array([-1,1]*3)
BL=r[:,None]*Q*r[None,:]
BLcodes=sorted({encode(BL[np.ix_(p,p)]) for p in permutations(range(n))})
blocks=[]
for t in [0.5,1.0]:
    lam=rho(np.ones((n,n))+t*BL)
    u=t/lam;q=(1-u)/(1+u);eta=1-(n-1)*u
    c=4*u**4*eta*q**(n-2)/((1+u)**2*(1+q**n)*(1+n*u))
    G=4*u*u*(3/(1+u*u*(n-1)**2)-1)/((1+n*u)/(1+u))
    repairs=0;repair_bad=0;max_returned_distance=0;repair_example=None
    nearly=0;bad=0;gap_min=float('inf');ratio_min=float('inf');witness=None
    for bits in range(1<<15):
        S=skew(n,bits);gap=lam-rho(np.ones((n,n))+t*S)
        near=bool(np.all(np.abs(S.sum(axis=1))==1));nearly+=near
        d=min((bits^b).bit_count() for b in BLcodes)
        if gap+1e-10<c*d: bad+=1
        if near:
            score=S.sum(axis=1)
            switched=score[:,None]*S*score[None,:]
            order=np.argsort(-np.linalg.solve(np.eye(n)-u*switched,np.ones(n)),kind='stable')
            X=switched[np.ix_(order,order)];rord=score[order]
            k=int(np.sum(np.triu(X,1)<0))
            neg=np.flatnonzero(rord<0);pos=np.flatnonzero(rord>0)
            target_order=np.array([v for pair in zip(neg,pos) for v in pair])
            rank=np.empty(n,dtype=int);rank[target_order]=np.arange(n)
            transitive=np.sign(rank[None,:]-rank[:,None])
            target=rord[:,None]*transitive*rord[None,:]
            dreturn=int(np.sum(np.triu(S[np.ix_(order,order)]-target,1)!=0))
            V=int(np.sum(np.abs(neg-np.arange(0,n,2))))
            repairs+=1;max_returned_distance=max(max_returned_distance,dreturn)
            if V>k or dreturn>k+V or gap+1e-10<c*dreturn:repair_bad+=1
            if d and (repair_example is None or gap<repair_example['gap']):
                repair_example={'bits':bits,'k':k,'adjacent_swaps_V':V,'returned_distance':dreturn,'nearest_distance':d,'gap':gap,'deficit_divided_by_c':gap/c}

        if d and gap<gap_min:
            gap_min=gap;witness={"bits":bits,"distance_nearest":d,"gap":gap,"nearly_regular":near}
        if d:ratio_min=min(ratio_min,gap/(c*d))
    blocks.append(dict(n=n,t=t,tournaments=1<<15,BL_labelled=len(BLcodes),nearly_regular=nearly,
        lambda0=lam,u=u,coefficient=c,non_nearly_regular_exclusion_threshold=G,
        bound_violations=bad,repair_cases=repairs,repair_violations=repair_bad,max_returned_distance=max_returned_distance,repair_example=repair_example,smallest_non_BL_gap=gap_min,
        min_gap_to_certified_c_times_nearest_distance=ratio_min,witness=witness))
out['all_six_vertex_tournaments']=blocks

# The weighted cospectral claim with arbitrary fixed labelled masses and diagonals.
# Direct exact characteristic polynomial for every transitive order at n=4.
z=sp.Symbol('z');m=list(map(sp.Rational,['1/3','5/4','2','7/3']))
g=list(map(sp.Rational,['0','2/7','3/2','4']))
t=sp.Rational(4,5)
Phi=sp.expand(((1+t)*sp.prod(z-g[i]+(1-t)*m[i] for i in range(4))
              -(1-t)*sp.prod(z-g[i]+(1+t)*m[i] for i in range(4)))/(2*t))
passed=0
for p in permutations(range(4)):
    pos={v:k for k,v in enumerate(p)}
    A=sp.Matrix(4,4,lambda i,j:g[i] if i==j else (1+t*(1 if pos[i]<pos[j] else -1))*m[j])
    if sp.expand(A.charpoly(z).as_expr()-Phi)!=0:raise RuntimeError('Weighted charpoly failure')
    passed+=1
out['exact_weighted_cospectrality']={"orders_checked":passed,"characteristic_polynomial":str(Phi),"status":"PASS"}

# Continuous box grids, zero diagonal allowed, skew entries include interior points.
gridresults=[]
for mass,diag,t in [([1,2,3],[0,0,0],0.3),([0.02,1.7,20],[9,0,0.2],0.97),([2,3,5],[0,4,1],0.01)]:
    mass=np.array(mass);diag=np.array(diag)
    def matrix(S):
        A=(1+t*S)*mass[None,:];np.fill_diagonal(A,diag);return A
    Q3=np.array([[0,1,1],[-1,0,1],[-1,-1,0]])
    minroot=rho(matrix(Q3));violations=0;equalities=0;maxerr=0
    for entries in product([-1,-.5,0,.5,1],repeat=3):
        S=np.zeros((3,3))
        for e,(i,j) in zip(entries,combinations(range(3),2)):S[i,j]=e;S[j,i]=-e
        gap=rho(matrix(S))-minroot
        violations+=gap< -1e-9
        equalities+=abs(gap)<1e-9
    gridresults.append({'m':mass.tolist(),'gamma':diag.tolist(),'t':t,'points':125,'violations':int(violations),'minimising_grid_points':int(equalities),'lambda_min':minroot})
out['continuous_box_grids']=gridresults

# Feasibility example directly from the model, and exact endpoint exception.
mass=np.array([1/3,2/3,1]);Q3=np.array([[0,1,1],[-1,0,1],[-1,-1,0]])
A=(1+.75*Q3)*mass[None,:];np.fill_diagonal(A,0)
H=np.ones((3,3))*mass[None,:];np.fill_diagonal(H,0)
out['feasibility_example']={'transitive_rho':rho(A),'symmetric_rho':rho(H),'Phi_at_1_exact':'13/48'}
B2=np.array([[0,-1],[1,0]])
out['section3_endpoint_exception']={'n':2,'t':1,'lambda0':rho(np.ones((2,2))+B2),'admissible_strict_u_bound':False}
out['elapsed_seconds']=time.time()-start
path=Path(__file__).with_name('independent_checks.json');path.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))

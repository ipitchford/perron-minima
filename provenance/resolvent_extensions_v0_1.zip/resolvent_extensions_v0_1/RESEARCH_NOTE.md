# Constructive resolvent ordering and weighted Perron minima
## Quantitative Brualdi–Li recovery and a heterogeneous extremal principle

**Research draft 0.1 — 27 September 2026**

**Assurance and scope.** This note contains two analytic developments of the supplied full-Levinger-path candidate. First, an exact nonnegative-summand identity replaces its compact-box minimum argument and gives an explicit spectral-deficit-to-edit-distance bound, with a constructive Brualdi–Li recovery rule. Second, a direct Perron argument determines every local and global minimum in a continuous class with arbitrary positive vertex weights and arbitrary nonnegative diagonal entries. These proofs are written out; the computational material checks their identities and finite consequences, not their universal validity by formal proof. Independent specialist review and historical priority remain outstanding. This note does not claim a sharp stability coefficient, a general weighted tournament maximum, or a four-star assessment.

## 1. Notation and relation to the literature

Let $J=\mathbf1\mathbf1^\top$ and let
$$\mathcal K_n=\{S:S^\top=-S,\ |S_{ij}|\le1\}.$$
A skew tournament has all off-diagonal entries $\pm1$. Let $Q_n$ have $+1$ above its diagonal and $-1$ below. Write $B_n=\operatorname{diag}(r_*)Q_n\operatorname{diag}(r_*)$, where $r_*=(-1,1,\ldots,-1,1)$ and $n$ is even. This is the Brualdi–Li skew tournament in an interleaved order. Edge distance counts differing unordered pairs; it is not a matrix norm with both triangular parts counted.

For $0<u<1/(n-1)$ define
$$R_S=(I-uS)^{-1},\quad f_u(S)=\mathbf1^\top R_S\mathbf1,\quad
q=\frac{1-u}{1+u},\quad F_n(u)=\frac{1-q^n}{u(1+q^n)}.$$
The positive-resolvent and odd-lattice ideas originate in the supplied unrefereed candidate, which is preserved unchanged. We give the arguments needed here, including a different constructive proof of its minimum lemma. Drury's classical endpoint theorem is credited, not assumed. The 2003 and 2006 papers of Psarrakos and Tsatsomeros study exactly the Levinger path after the affine change
$$I+2[(1-\alpha)T+\alpha T^\top]=J+(1-2\alpha)(T-T^\top).$$
Their complete supplied texts were inspected in the preceding source audit; their projection, derivative and variance bounds are established background. The weighted theorem in Section 5 has a rank-one symmetric part only when its diagonal is the squared weight vector: in general its symmetric part is *diagonal plus rank one*. We do not identify those two classes.

## 2. A constructive quantitative ordering identity

Put
$$\eta=1-(n-1)u,\qquad B=\frac{1+nu}{1+u},\qquad
 a_n(u)=\frac{4u^2\eta q^{n-2}}{(1+u)^3(1+q^n)}.$$
All three quantities are positive.

**Lemma 2.1 (positive vectors and quantitative bounds).** For every $S\in\mathcal K_n$, the vectors $x=R_S\mathbf1$ and $R_S^\top\mathbf1$ are strictly positive and
$$\frac{\eta}{1+u}\le\min_i x_i\le\max_i x_i\le B.$$

**Proof.** Follow $(I-vS)^{-1}\mathbf1$ from $v=0$ until a first hypothetical zero. At that point $x\ge0$, $\|x\|_2^2=\mathbf1^\top x=f$, and at most $n-1$ entries are nonzero. Thus $f\le n-1$. The zero-coordinate equation gives $1\le vf\le u(n-1)<1$, a contradiction. Replace $S$ by $-S$ for the transpose. Also $f\le n$ by Cauchy–Schwarz. The $i$th equation gives $(1+u)x_i\le1+uf\le1+un$. Finally
$$0\le\sum_{j\ne i}(x_j-1)^2=n-1-f+2x_i-x_i^2$$
implies $f\le n-1+2x_i$. Since $x_i\ge1-u(f-x_i)$, it follows that $(1+u)x_i\ge\eta$. $\square$

Order the vertices so that $x_1\ge\cdots\ge x_n$. Ties may be broken in any way. In this order put
$$y=(I+uQ_n)^{-1}\mathbf1,\qquad
 y_i=Cq^{n-i},\quad C=\frac2{(1+u)(1+q^n)}.$$

**Theorem 2.2 (ordering certificate).** In the selected order,
$$\boxed{f_u(S)-F_n(u)=u\sum_{i<j}(1-S_{ij})(y_jx_i-y_ix_j).} \tag{2.1}$$
Every summand is nonnegative. In particular, if
$$E(S)=\sum_{i<j}(1-S_{ij})$$
is the distance from $S$ to the transitive vertex in this order, then
$$\boxed{f_u(S)-F_n(u)\ge a_n(u)E(S).} \tag{2.2}$$
Equality $f_u(S)=F_n(u)$ holds exactly at transitive tournament vertices.

**Proof.** The resolvent identity is
$$R_S-R_Q=uR_Q(S-Q)R_S.$$
Multiply by the all-ones vectors and pair the $(i,j)$ and $(j,i)$ terms to obtain (2.1). The geometric formula for $y$ follows by subtracting adjacent equations; its sum is $F_n(u)$. For $i<j$, $y_j>y_i$, and $x_i\ge x_j>0$, so
$$y_jx_i-y_ix_j=(y_j-y_i)x_i+y_i(x_i-x_j)
\ge Cq^{n-2}(1-q)\frac{\eta}{1+u}.$$
Substitution gives (2.2). All coefficients in (2.1) are strictly positive apart from the factor $1-S_{ij}$, proving the equality assertion. $\square$

This is not a claim that $f_u$ is convex. It supplies a particular order and an exact certificate for every input. One linear solve and a sort suffice. It gives, in particular, a quantitative result on the *continuous* skew box, not only on its tournament vertices.

## 3. Parity, strict score exclusion and the classical extremal matrix

The symmetric part of $R_S$ is
$$H_S=(I-u^2S^2)^{-1},\qquad 0\prec H_S\preceq I.$$
For every odd integer vector $z\in\mathbf1+2\mathbb Z^n$,
$$z^\top R_Sz\ge F_n(u). \tag{3.1}$$
Indeed, minimise $z^\top H_Sz$ over that lattice coset. Coercivity gives a minimiser. Comparison with $z\pm2e_i$ gives $|(H_Sz)_i|\le(H_S)_{ii}\le1$. Since
$$\|H_S^{-1}\|_\infty\le d_u:=1+u^2(n-1)^2<2,$$
the minimiser has infinity norm below two, hence every coordinate is $\pm1$. Switching by those signs reduces (3.1) to Theorem 2.2. Equality additionally requires the switched skew matrix to be transitive.

**Lemma 3.1 (strict odd-vector penalty).** If an odd vector $z$ has $\|z\|_\infty\ge3$, then
$$\boxed{z^\top R_Sz\ge F_n(u)+4\left(\frac{\|z\|_\infty}{d_u}-1\right).} \tag{3.2}$$

**Proof.** With $w=H_Sz$, some $|w_i|\ge\|z\|_\infty/d_u$. Replacing $z$ by $z-2\operatorname{sign}(w_i)e_i$ lowers its quadratic form by
$$4(|w_i|-(H_S)_{ii})\ge4(\|z\|_\infty/d_u-1).$$
The new vector is still odd, so (3.1) applies. $\square$

For an even-order tournament $S$, $r=S\mathbf1$ is odd and
$$f_u(S)=n-u^2r^\top R_Sr. \tag{3.3}$$
Thus $f_u(S)\le n-u^2F_n(u)$. Equality forces $r_i=\pm1$ and $\operatorname{diag}(r)S\operatorname{diag}(r)$ transitive. If the latter is reordered to $Q_n$, its score equation is $Q_nr=\mathbf1$. Subtracting adjacent rows and using the last row gives $r=r_*$. Therefore equality forces Brualdi–Li, and direct substitution proves attainment.

For $0<t\le1$ let
$$\lambda_0=\rho(J+tB_n),\qquad u=t/\lambda_0.$$
The row sums of the Brualdi–Li matrix are $n\pm t$; its irreducibility at $t=1$ gives $\lambda_0>n-1$. For example, in the equivalent two-block Brualdi–Li order, the directed path through the first block and then the second closes to a Hamilton cycle; the two row sums differ, so the Perron row-sum inequality is strict. Hence $u<1/(n-1)$. Moreover
$$\lambda_0=n-u^2F_n(u),\qquad t=u\lambda_0. \tag{3.4}$$
For arbitrary $S$, $x=R_S\mathbf1>0$ satisfies
$$(J+tS)x=\lambda_0x+(f_u(S)-\lambda_0)\mathbf1.$$
The Perron row-ratio bound therefore gives the useful quantitative inequality
$$\boxed{\lambda_0-\rho(J+tS)\ge\frac{\lambda_0-f_u(S)}{\max_i x_i}
\ge\frac{\lambda_0-f_u(S)}B.} \tag{3.5}$$
This reproves the candidate's all-parameter comparison without its compact-box derivative argument. It is a self-contained reuse of its parity mechanism, not an additional priority claim for Drury's endpoint.

If $S$ is not nearly regular, then $\|r\|_\infty\ge3$. Equations (3.2)–(3.5) give
$$\boxed{\lambda_0-\rho(J+tS)\ge G_n(u):=
\frac{4u^2}{B}\left(\frac3{1+u^2(n-1)^2}-1\right)>0.} \tag{3.6}$$
A deficit below this explicit threshold therefore certifies near regularity.

## 4. Global spectral stability with constructive recovery

Suppose first that $r_i=\pm1$. Set $W=\operatorname{diag}(r)S\operatorname{diag}(r)$ and order it by decreasing entries of $(I-uW)^{-1}\mathbf1$. Let $k$ be its number of backward edges in this order. Then $E(W)=2k$, and
$$\lambda_0-f_u(S)=u^2[f_u(W)-F_n(u)]\ge2a_n(u)u^2k. \tag{4.1}$$

**Lemma 4.1 (alternating repair).** A Brualdi–Li tournament on the original labels can be constructed at edge distance at most $2k$ from $S$.

**Proof.** In the chosen order, $Wr=\mathbf1$ and $\sum_i r_i=0$. Put
$$b=(Q_n-W)r=Q_nr-\mathbf1.$$
Each backward edge contributes magnitude two at each of its endpoints, so $\sum_i|b_i|\le4k$. Let the positions of the negative signs be $p_1<\cdots<p_{n/2}$ and those of the positive signs be $q_1<\cdots<q_{n/2}$, using one-based indexing. Directly from the formula for $Q_nr$,
$$b_{p_j}=-2[p_j-(2j-1)],\qquad b_{q_j}=2(q_j-2j).$$
The number $V$ of adjacent exchanges required to transform this binary word stably into $(-,+,-,+,\ldots)$ equals both
$$\sum_j|p_j-(2j-1)|\quad\text{and}\quad\sum_j|q_j-2j|.$$
One proof matches equal signs in their relative orders; every exchange moves one negative and one positive sign one place towards their required positions. It is also the transport cost of the two binary sequences. Consequently $4V=\sum_i|b_i|\le4k$.

Changing the transitive order by those $V$ adjacent swaps changes exactly $V$ tournament edges. The original $W$ differs from that new transitive order in at most $k+V\le2k$ edges. Switching back by $r$ preserves edge differences, and the signs now alternate in the new order, producing Brualdi–Li. $\square$

Define
$$\boxed{c_n(u)=\frac{a_n(u)u^2}{B}
=\frac{4u^4[1-(n-1)u]q^{n-2}}
{(1+u)^2(1+q^n)(1+nu)}.} \tag{4.2}$$

**Theorem 4.2 (all-parameter constructive spectral stability).** For every even $n\ge4$, every tournament $S$ and every $0<t\le1$, an explicitly constructed Brualdi–Li copy $S^\sharp$ satisfies
$$\boxed{\rho(J+tB_n)-\rho(J+tS)\ge c_n(u)\,d_E(S,S^\sharp),\qquad u=t/\lambda_0.} \tag{4.3}$$
Hence the same inequality holds with the minimum edit distance over all Brualdi–Li copies.

**Proof.** In the nearly regular case combine (3.5), (4.1) and Lemma 4.1. In the remaining case return any fixed Brualdi–Li copy, at distance at most $N=n(n-1)/2$. We have $G_n(u)\ge2u^2/B$ and $c_n(u)\le4u^4\eta/B$. Writing $v=u(n-1)\in(0,1)$,
$$2Nu^2\eta=\frac n{n-1}v^2(1-v)\le\frac{16}{81}<1.$$
Thus $Nc_n(u)\le G_n(u)$, and (3.6) proves the assertion. $\square$

The algorithm uses a score computation, one linear solve in the nearly regular case, sorting and stable interleaving. This is $O(n^3)$ arithmetic operations, excluding the scalar root calculation for (3.4); no optimal feedback-arc solver or enumeration of relabellings is required. It does **not** necessarily return a nearest Brualdi–Li copy.

The coefficient is explicit but not sharp. At fixed $n$ as $t\downarrow0$, $c_n(u)\sim2t^4/n^4$, while the score-exclusion threshold is of order $t^2$. The fourth-order scale for near-regular competitors agrees with the separate cycle-count addendum, but not its optimal coefficient. Constants deteriorate with dimension. The result applies to tournament matrices; extending it to arbitrary reciprocal matrices near their envelope requires another rounding argument and is not claimed here.

For exact certification it is convenient to choose rational $u$ and set rational $\lambda_0=n-u^2F_n(u)$ and $t=u\lambda_0$, checking $t\le1$. The returned vector gives an exact rational lower bound in (3.5) without numerical eigendecomposition. General rational $t$ can instead use certified intervals for $u$. The included command-line interface exposes the first, entirely rational option.

## 5. A weighted Perron minimum with arbitrary diagonal

The second development removes the equal-weight assumption in a different direction. Fix $n\ge2$, $m_i>0$, $\gamma_i\ge0$ and $0<t<1$. Consider matrices
$$A_{ii}=\gamma_i,\qquad
 A_{ij}=\sqrt{m_im_j}(1+tS_{ij})\quad(i\ne j),\qquad S\in\mathcal K_n. \tag{5.1}$$
They have a fixed diagonal and a factorised symmetric off-diagonal part. Put
$$w_i=\sqrt{m_i},\quad W=\operatorname{diag}(w),\quad D=\operatorname{diag}(\gamma_i-m_i),$$
so $A=D+ww^\top+tWSW$. Every off-diagonal entry is strictly positive. The diagonal may vanish, but the Perron eigenvalue is simple and its left and right vectors are strictly positive.

**Theorem 5.1 (all local minima are global).** Every local minimum of $S\mapsto\rho(A(S))$ on the skew box is a saturated transitive orientation. Conversely every saturated transitive orientation is a global minimum. All $n!$ such orientations have the same characteristic polynomial, although for unequal prescribed data they need not be permutationally similar within the labelled class.

The minimum $\lambda_-$ is the unique root greater than $\max_i\gamma_i$ of
$$\boxed{
\prod_i\frac{\lambda-\gamma_i+(1-t)m_i}
                 {\lambda-\gamma_i+(1+t)m_i}
=\frac{1-t}{1+t}.} \tag{5.2}$$
Equivalently it is the root of
$$\Phi(\lambda)=\frac{(1+t)\prod_i[\lambda-\gamma_i+(1-t)m_i]
-(1-t)\prod_i[\lambda-\gamma_i+(1+t)m_i]}{2t}. \tag{5.3}$$

### 5.1 Excluding nonglobal local minima

At a given $S$, let $\lambda=\rho(A)>\max_i\gamma_i$. The strict inequality follows immediately from each positive Perron-vector row equation. Set
$$Z=\lambda I-D\succ0,\quad K=tWSW,\quad R=(Z-K)^{-1},\quad x=Rw,\quad y=R^\top w.$$
The Perron equations imply $x,y>0$ and $w^\top Rw=1$. Also
$$\frac{R+R^\top}{2}=R^\top ZR\succ0. \tag{5.4}$$
For the function $f(\lambda,S)=w^\top Rw$, holding $\lambda$ fixed,
$$f_\lambda=-y^\top x<0.$$
For one skew coordinate, let $E=t\sqrt{m_im_j}(e_ie_j^\top-e_je_i^\top)$. Then
$$f_s=y^\top Ex,\qquad f_{ss}=2y^\top ERE x.$$
If the spectral derivative vanishes, then $f_s=0$, hence $y_i/x_i=y_j/x_j=\zeta>0$. It follows that
$$f_{ss}=-2\zeta(Ex)^\top R(Ex)<0.$$
Implicit differentiation of $f(\lambda(s),S(s))=1$ gives, at that critical point,
$$\lambda''=-f_{ss}/f_\lambda<0. \tag{5.5}$$
Such a point cannot be a local minimum, even at an endpoint of that coordinate. Therefore every coordinate of a local minimum is at $\pm1$ and every ratio $y_i/x_i$ is distinct. Order those ratios increasingly. Since
$$\lambda_s=\frac{t\sqrt{m_im_j}(y_ix_j-y_jx_i)}{y^\top x},$$
its sign forces $S_{ij}=1$ for $i<j$. This is transitivity. No convexity or concavity of the Perron root on the full matrix domain is assumed. That distinction is essential: global concavity along general Levinger paths is false, as Altenberg and Cohen (2020) demonstrate.

### 5.2 Evaluation, cospectrality and uniqueness of the scalar root

Write $a_i=\lambda-\gamma_i+m_i$. For a transitive order, diagonal expansion gives
$$\det(\lambda I-D-tWQ_nW)
=\frac12\left\{\prod_i(a_i+tm_i)+\prod_i(a_i-tm_i)\right\}.$$
Each even principal minor of $Q_n$ has determinant one, and each odd one is zero. The even statement follows by induction from the Pfaffian expansion, whose alternating sum is one. This also directly proves the displayed product identity.

For $\lambda>\max\gamma_i$, all $a_i>m_i>tm_i$. Put
$$P=\prod_i\frac{a_i-tm_i}{a_i+tm_i}.$$
For completeness, solve $(\operatorname{diag}(a_i/m_i)-tQ_n)v=\mathbf1$, and put $f=\sum_i v_i$, $C_i=\sum_{j\le i}v_j$, and $z_i=1+tf-2tC_i$. The row equations give
$$(a_i/m_i+t)v_i=1+tf-2tC_{i-1},\qquad
z_i=z_{i-1}\frac{a_i-tm_i}{a_i+tm_i}.$$
Since $z_0=1+tf$ and $z_n=1-tf$, we obtain
$$w^\top(\lambda I-D-tWQ_nW)^{-1}w=f=\frac{1-P}{t(1+P)}.$$
The rank-one determinant identity now gives exactly (5.3). It holds first on an open half-line and hence as a polynomial identity everywhere. Its product form is symmetric in the pairs $(m_i,\gamma_i)$, so every order is cospectral.

The ratio in (5.2) is strictly increasing on $\lambda>\max\gamma_i$. At the left endpoint one factor equals $(1-t)/(1+t)$ and every other factor is strictly below one; their product is therefore smaller than the target. At infinity the product tends to one. There is a unique root in the interval. Every transitive matrix has that Perron root. A global minimum exists by compactness and must be transitive by Section 5.1, proving the converse and completing Theorem 5.1. $\square$

The statement includes arbitrary positive weight ratios. It is not a perturbative theorem near equal weights. The strict restriction $t<1$ is needed for the equality and local-minimum classification. At $t=1$ the minimum is $\max\gamma_i$, attained by transitive matrices, but other reducible orientations can also attain it. At $t=0$ the class is a single matrix.

## 6. Complete spectral range and limits of weighted extrapolation

Let $H=D+ww^\top$ and let $v_H>0$ be its Perron vector. The maximum over (5.1) is
$$\boxed{\lambda_+=\rho(H),}$$
with equality exactly when $WSWv_H=0$. Indeed a right Perron vector $v$ gives
$$\rho(A)=\frac{v^\top Av}{v^\top v}=\frac{v^\top Hv}{v^\top v}\le\rho(H).$$
Equality forces $v$ into the simple top eigenspace of $H$, and then the eigenvector equation forces the displayed null condition. Conversely that condition supplies a positive Perron vector. The choice $S=0$ always attains the bound. Continuity on the connected compact skew box shows that its Perron values fill the interval $[\lambda_-,\lambda_+]$.

The upper bound and its proof are standard symmetric-part Rayleigh theory; the claimed development is the exact lower endpoint and its global landscape. When $\gamma_i=m_i$, the symmetric part is precisely $ww^\top$, $\lambda_+=\sum m_i$, and upper equality is $S m=0$. Equation (5.2) becomes
$$\sum_i\operatorname{artanh}(tm_i/\lambda_-)=\operatorname{artanh}t.$$
For $m_i=\gamma_i=1$ this gives
$$\boxed{\lambda_-=t\coth\!\left(\frac{\operatorname{artanh}t}{n}\right).}$$
Thus transitive tournaments minimise the full path, while the earlier theorem determines its even-order tournament maximum. The two-sided statement does not replace the distinction between the continuous box and its tournament vertices: the box maximum is $n$, and an even-order tournament cannot attain it.

### 6.1 Exact feasibility of stabilising a positive linear system

For a recurrence $z_{k+1}=Az_k$, some admissible redistribution (5.1) has spectral radius below one if and only if
$$\max_i\gamma_i<1\quad\text{and}\quad\Phi(1)>0.$$
This is immediate from the strictly increasing ratio in (5.2). It gives an exact rational decision for rational input parameters; the statement concerns only the specified factorised interaction model, not an arbitrary network.

For example, with $m=(1/3,2/3,1)$, $\gamma=(0,0,0)$ and $t=3/4$, $\Phi(1)=13/48>0$. The minimum is approximately $0.8706616645$, whereas the symmetric member has spectral radius approximately $1.2554784946$. The scalar sign certifies the first inequality without relying on those decimals.

### 6.2 A weighted maximum is not a universal Brualdi–Li analogue

Use five vertices in cyclic blocks of sizes $3,1,1$, orient the three-vertex block cyclically, and orient the blocks as a directed triangle. With weights
$$m=(1,1,1,3,3),$$
its skew tournament has $Sm=0$. It therefore attains the exact continuous upper endpoint $9$ for every $0<t<1$ when $\gamma=m$.

It is not switching-equivalent to a transitive tournament. The kernel of an odd transitive skew tournament is spanned by an alternating sign vector, so every nonzero kernel vector of a switched transitive matrix has constant absolute coordinates. Our displayed positive kernel vector does not. Hence no switched transitive tournament attains the weighted upper endpoint for these weights.

This counterexample prevents an unjustified extrapolation of the equal-weight maximiser. We do not solve the general weighted tournament maximum.

## 7. Verification, originality and limitations

The supplied envelope's default replay was rerun: all three jobs and its 47-file manifest passed. The large finite-order Bernstein and floating-point full-replay jobs were not regenerated in this turn. Its archive and the earlier full-text comparison archive are preserved unchanged.

The new standard-library verifier checks the ordering identity and quantitative coefficient directly with rational inverses, the strengthened odd-vector penalty, stable alternating repair, and the positive comparison-vector identity. The weighted characteristic polynomial is checked against direct determinants after several different transitive orders. A separate integer fixed-point iteration constructs positive test vectors for exact Collatz row-ratio certificates: numerical convergence is not presumed and no floating-point value authorises an inequality. SymPy reconstructs the formulas independently without importing the rational routines.

Both proof-critical check paths raise explicit exceptions. Negative-control tests alter nontrivial stored determinant and resolvent identities, as well as a positivity condition, in disposable copies. Their manifests are recomputed. They are required to fail both directly and through the replay wrapper under ordinary execution, `-O`, `-OO`, `PYTHONOPTIMIZE=1` and `PYTHONOPTIMIZE=2`. The valid inputs must pass all those modes.

The numerical optimisation records retain every start, termination status, result and discrepancy. They corroborate the no-spurious-minimum theorem but do not prove it. The analytic arguments establish arbitrary dimension. None of the scripts is proof-assistant verification.

**Research positioning.** The old papers already treat the fixed-rank-one Levinger framework, Perron-vector geometry and variance-dependent bounds. Resolvent identities, Perron differentiation, rank-one determinant identities and the Rayleigh principle are classical. The candidate contribution here is their explicit constructive ordering remainder, the edit-distance recovery theorem and the all-weight/all-diagonal minimum classification. A targeted search did not find these precise statements, but that is not exhaustive historical priority. Drury's full published argument and the older arc-reversal literature have not all been audited in full. No independent specialist endorsement is inferred from previous generated review material.

**Unresolved.** The edit coefficient is not sharp, the recovery output need not minimise edits, and no quantitative rounding theorem for general reciprocal matrices is supplied. The heterogeneous maximum over tournament vertices remains unsolved; the five-vertex example shows why its optimiser is not always a switched transitive structure. No complexity bound uniform over extreme numerical conditioning is asserted. These are research drafts, not a publication or a rating claim.

\newpage

## References

### Classical Levinger and tournament context

Drury, S. W. (2012). Solution of the conjecture of Brualdi and Li. *Linear Algebra and its Applications, 436*(9), 3392–3399. <https://doi.org/10.1016/j.laa.2011.11.031>

Psarrakos, P. J., & Tsatsomeros, M. J. (2003). The Perron eigenspace of nonnegative almost skew-symmetric matrices and Levinger's transformation. *Linear Algebra and its Applications, 360*, 43–57. <https://doi.org/10.1016/S0024-3795(02)00439-1>

Psarrakos, P. J., & Tsatsomeros, M. J. (2006). Bounds for Levinger's function of nonnegative almost skew-symmetric matrices. *Linear Algebra and its Applications, 416*(2–3), 759–772. <https://doi.org/10.1016/j.laa.2005.12.018>

### Source and derivative boundaries

Altenberg, L., & Cohen, J. E. (2020). Nonconcavity of the spectral radius in Levinger’s theorem. *Linear Algebra and its Applications, 606*, 201–218. <https://doi.org/10.1016/j.laa.2020.07.028>. Preprint: <https://arxiv.org/abs/2007.02618>

*Brualdi–Li extremality along the full Levinger path*. (2026). Research version 0.1. Supplied unrefereed predecessor, preserved with a hash in the evidence bundle. Its primary new lemmas are reproved or strengthened above, not promoted to externally accepted results.

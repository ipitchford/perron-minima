# Claims and evidence

| Claim | Proof | Independent computational check | What is not established by the check |
|---|---|---|---|
| Positive resolvent vectors and bounds | Lemma 2.1, first-zero argument | Exact rational skew arrays | Universal positivity is analytic |
| Constructive sum identity and quantitative coefficient | Theorem 2.2, resolvent identity and sorting | Rational inverses; independent symbolic 3-point reconstruction | Finite cases do not prove all n |
| Strict odd-lattice penalty | Lemma 3.1, coordinate descent comparison | Exact odd-vector tests and stored fixtures | No exhaustive infinite lattice enumeration |
| Spectral gap and recovery | Theorem 4.2, score split and alternating repair | 272 rational spectral certificates; 2,640 six-point nearly regular inputs; 1,272 binary-word cases | Coefficient is not sharp; output is not nearest edit solution |
| Heterogeneous minimum and absence of nonglobal local minima | Theorem 5.1, implicit Perron derivatives | Independent derivatives; 30 bounded optimisation starts | Optimisation is corroboration only |
| Every transitive order is cospectral | Section 5.2, product characteristic polynomial | 90 direct determinants; 288 transitive equality cases | All-data identity follows from proof |
| Exact weighted lower bound | Unique root and minimum theorem | 2,176 labelled-tournament row-ratio certificates; numerical/high-precision comparisons | Does not solve weighted maximum |
| Obstruction to switched-transitive maximum | Section 6.2, exact positive kernel and odd Q kernel | Three rational parameters and symbolic kernel | Does not classify other weighted maximisers |
| Verifier rejects corrupted certificates | Explicit exception checks | 10 valid runs and 30 recomputed-manifest corruptions across five modes | Not exhaustive software verification |

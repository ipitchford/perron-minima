#!/usr/bin/env python3
import json
from pathlib import Path
from fractions import Fraction as F
from core import *
ROOT=Path(__file__).resolve().parents[1]
def main():
    data=json.loads((ROOT/'reference.json').read_text())
    for record in data['weighted_determinants']:
        m=list(map(F,record['m']));g=list(map(F,record['gamma']));t=F(record['t']);lam=F(record['lambda'])
        n=len(m);A=weighted_matrix(m,g,t,Q(n))
        actual=det([[lam*F(i==j)-A[i][j] for j in range(n)] for i in range(n)])
        require(actual==F(record['determinant']),'weighted determinant reference mismatch')
    for rec in data['resolvent_gaps']:
        S=tournament(rec['n'],rec['bits']);u=F(rec['u']);fm,*_=constants(len(S),u)
        actual=sum(mv(resolvent(S,u),[F(1)]*len(S)))-fm
        require(actual==F(rec['gap']),'resolvent gap reference mismatch')
    need_coeff=list(map(F,data['strict_gap_factors']))
    require(all(v>0 for v in need_coeff),'nonpositive inequality coefficient')
    require(need_coeff==[F(3),F(1),F(4)],'odd lattice identity coefficients changed')
    print(json.dumps({'status':'PASS','weighted_references':len(data['weighted_determinants']),'resolvent_references':len(data['resolvent_gaps']),'coefficient_checks':3},sort_keys=True))
if __name__=='__main__':main()

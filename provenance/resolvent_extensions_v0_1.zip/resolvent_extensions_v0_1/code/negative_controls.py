#!/usr/bin/env python3
import tempfile,shutil,json,subprocess,os,sys,hashlib,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def build_manifest(root):
    paths=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.sha256' and '__pycache__' not in p.parts)
    (root/'MANIFEST.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in paths))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--part',choices=['none','wrong_determinant','wrong_resolvent_gap','negative_coefficient']);args=ap.parse_args()
    modes=[('ordinary',[],None),('-O',['-O'],None),('-OO',['-OO'],None),('env1',[],'1'),('env2',[],'2')];records=[]
    with tempfile.TemporaryDirectory() as td:
        for corruption in ([args.part] if args.part else ['none','wrong_determinant','wrong_resolvent_gap','negative_coefficient']):
            b=Path(td)/corruption;(b/'code').mkdir(parents=True)
            for f in ['core.py','verify_reference.py']:shutil.copy2(ROOT/'code'/f,b/'code'/f)
            shutil.copy2(ROOT/'replay.py',b/'replay.py');data=json.loads((ROOT/'reference.json').read_text())
            if corruption=='wrong_determinant':data['weighted_determinants'][0]['determinant']='-999'
            if corruption=='wrong_resolvent_gap':data['resolvent_gaps'][0]['gap']='-1'
            if corruption=='negative_coefficient':data['strict_gap_factors'][0]='-3'
            (b/'reference.json').write_text(json.dumps(data,sort_keys=True)+'\n');build_manifest(b)
            for mode,flags,optimise in modes:
                env=os.environ.copy();env.pop('PYTHONOPTIMIZE',None);env['PYTHONDONTWRITEBYTECODE']='1'
                if optimise:env['PYTHONOPTIMIZE']=optimise
                for wrapper in [False,True]:
                    cmd=[sys.executable,*flags,*(['replay.py','--smoke'] if wrapper else ['code/verify_reference.py'])]
                    p=subprocess.run(cmd,cwd=b,env=env,capture_output=True,text=True,timeout=20)
                    ok=p.returncode==0
                    if ok!=(corruption=='none'):raise RuntimeError('unsafe verifier outcome '+str((corruption,mode,wrapper)))
                    records.append({'corruption':corruption,'mode':mode,'wrapper':wrapper,'accepted':ok})
    report={'status':'PASS','valid_acceptances':sum(x['accepted'] for x in records),'invalid_rejections':sum(not x['accepted'] for x in records),'tests':records,'scope':'Three nontrivial invalid fixtures; no claim of exhaustive software correctness.'}
    (ROOT/'results'/('negative_'+args.part+'.json' if args.part else 'negative_controls.json')).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','valid_acceptances':report['valid_acceptances'],'invalid_rejections':report['invalid_rejections']},sort_keys=True))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Corroboration only. Every optimiser status, start and objective is retained."""
from pathlib import Path
import json
import numpy as np
from scipy.linalg import eig
from scipy.optimize import minimize
from core import F,minimum_bracket,require
ROOT=Path(__file__).resolve().parents[1]
def build(n,z,m,g,t):
    S=np.zeros((n,n));ix=np.triu_indices(n,1);S[ix]=z;S-=S.T
    w=np.sqrt(m);return np.diag(g-m)+(1+t*S)*np.outer(w,w)
def value(n,z,m,g,t):
    A=build(n,z,m,g,t);vals,left,right=eig(A,left=True,right=True)
    k=np.argmax(vals.real);v=right[:,k].real;y=left[:,k].real
    q=np.dot(y,v);ii,jj=np.triu_indices(n,1)
    grad=t*np.sqrt(m[ii]*m[jj])*(y[ii]*v[jj]-y[jj]*v[ii])/q
    return vals[k].real,grad

def main():
    rng=np.random.default_rng(9272026);rows=[]
    for n in [3,4,5,6,8]:
        for j in range(6):
            mf=[F(int(x),8) for x in rng.integers(1,49,size=n)];gf=[F(int(x),8) for x in rng.integers(0,17,size=n)]
            tf=[F(1,5),F(3,5),F(19,20)][j%3];m=np.array(mf,float);g=np.array(gf,float);t=float(tf)
            start=rng.uniform(-1,1,n*(n-1)//2);lo,hi=minimum_bracket(mf,gf,tf)
            r=minimize(lambda z:value(n,z,m,g,t),start,jac=True,bounds=[(-1,1)]*len(start),method='L-BFGS-B',options={'maxiter':2000,'ftol':1e-13,'gtol':1e-9})
            gap=float(r.fun)-float((lo+hi)/2)
            require(gap>=-1e-8,'numerical minimum apparently violates theorem')
            rows.append({'n':n,'m':list(map(str,mf)),'gamma':list(map(str,gf)),'t':str(tf),'initial':start.tolist(),'result':r.x.tolist(),'success':bool(r.success),'message':str(r.message),'iterations':int(r.nit),'objective':float(r.fun),'reference_root':float((lo+hi)/2),'deficit_above_minimum':gap})
    # Independent high precision determinant root / Perron computation.
    import mpmath as mp
    mp.mp.dps=65;hp=[]
    for n in [3,4,5,6]:
        mf=[F(i+1,3) for i in range(n)];gf=[F((2*i+1)%5,4) for i in range(n)];tf=F(4,5)
        lo,hi=minimum_bracket(mf,gf,tf,220)
        conv=lambda x:mp.mpf(x.numerator)/x.denominator
        M=mp.matrix([[conv(gf[i]) if i==j else (1+conv(tf)*(1 if i<j else -1))*conv(mf[j]) for j in range(n)] for i in range(n)])
        vals=mp.eig(M,left=False,right=False);v=max(vals,key=lambda x:mp.re(x));err=abs(v-conv((lo+hi)/2))
        require(err<mp.mpf('1e-59'),'high-precision root disagreement')
        hp.append({'n':n,'perron':mp.nstr(v,62),'midpoint_error':mp.nstr(err,8)})
    report={'status':'PASS','seed':9272026,'optimisation_attempts':len(rows),'successes':sum(r['success'] for r in rows),'worst_objective_gap':max(r['deficit_above_minimum'] for r in rows),'most_negative_gap':min(r['deficit_above_minimum'] for r in rows),'trials':rows,'high_precision':hp,'scope':'Floating point corroboration; optimiser convergence is not a mathematical certificate.'}
    (ROOT/'results'/'numerical.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['trials','high_precision']},sort_keys=True))
if __name__=='__main__':main()

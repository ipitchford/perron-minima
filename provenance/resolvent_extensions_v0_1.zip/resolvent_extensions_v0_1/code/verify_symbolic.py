#!/usr/bin/env python3
"""Independent SymPy reconstructions; no imports from the rational implementation."""
from pathlib import Path
import json
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
def need(ok,msg):
    if not ok:raise ValueError(msg)
def zero(x,msg):need(s.cancel(x)==0,msg)
def main():
    jobs=[]
    u=s.symbols('u',positive=True);a,b,c=s.symbols('a b c',real=True)
    S=s.Matrix([[0,a,b],[-a,0,c],[-b,-c,0]]);Q=s.Matrix([[0,1,1],[-1,0,1],[-1,-1,0]]);one=s.ones(3,1)
    R=(s.eye(3)-u*S).inv();RQ=(s.eye(3)-u*Q).inv();x=R*one;y=RQ.T*one
    expression=sum(u*(1-S[i,j])*(y[j]*x[i]-y[i]*x[j]) for i in range(3) for j in range(i+1,3))
    zero((one.T*(R-RQ)*one)[0]-expression,'ordering identity');jobs.append('generic_3x3_ordering_identity')
    need(s.simplify((R+R.T)/2-(s.eye(3)-u*u*S*S).inv())==s.zeros(3),'symmetric resolvent');jobs.append('symmetric_resolvent')
    n=s.symbols('n',integer=True,positive=True);q=s.symbols('q',positive=True)
    q0=(1-u)/(1+u);C=2/((1+u)*(1+q**n))
    zero(u*(1-(n-1)*u)/(1+u)*C*q**(n-2)*(1-q0)-4*u*u*(1-(n-1)*u)*q**(n-2)/((1+u)**3*(1+q**n)),'ordering coefficient');jobs.append('explicit_ordering_coefficient')
    # Generic weighted characteristic polynomial, constructed from original matrices.
    z,t=s.symbols('z t');ms=s.symbols('m0:3',positive=True);gs=s.symbols('g0:3',nonnegative=True)
    for n0 in [2,3]:
        A=s.Matrix(n0,n0,lambda i,j:gs[i] if i==j else (1+t*(1 if i<j else -1))*ms[j])
        pm=s.prod(z-gs[i]+(1-t)*ms[i] for i in range(n0));pp=s.prod(z-gs[i]+(1+t)*ms[i] for i in range(n0))
        zero((z*s.eye(n0)-A).det()-((1+t)*pm-(1-t)*pp)/(2*t),'weighted characteristic');jobs.append('weighted_characteristic_n'+str(n0))
    # Two-state original matrix gives an independent closed-form check of the minimum.
    g0,g1,m0,m1=s.symbols('g0 g1 m0 m1',positive=True)
    lam=(g0+g1+s.sqrt((g0-g1)**2+4*m0*m1*(1-t*t)))/2
    zero((lam-g0)*(lam-g1)-m0*m1*(1-t*t),'two_state');jobs.append('two_state_closed_form')
    # Symmetric part of (Z-K)^(-1) is positive, with no norm restriction.
    Z=s.diag(2,3,5);K=s.Matrix([[0,a,b],[-a,0,c],[-b,-c,0]]);U=(Z-K).inv()
    need(s.simplify((U+U.T)/2-U.T*Z*U)==s.zeros(3),'accretive inverse identity');jobs.append('accretive_inverse')
    # Differentiation at fixed lambda before the implicit Perron equation.
    w=s.Matrix([1,2,3]);D=s.diag(0,s.Rational(1,2),-1)
    X=(z*s.eye(3)-D-K).inv();xx=X*w;yy=X.T*w;f=(w.T*X*w)[0];E=s.Matrix([[0,1,0],[-1,0,0],[0,0,0]])
    zero(s.diff(f,a)-(yy.T*E*xx)[0],'weighted first derivative');zero(s.diff(f,z)+(yy.T*xx)[0],'lambda derivative')
    zero(s.diff(f,a,2)-2*(yy.T*E*X*E*xx)[0],'weighted second derivative');jobs.append('weighted_implicit_derivatives')
    v=s.symbols('v',real=True)
    zero(s.diff(v*v*(1-v),v)-v*(2-3*v),'cubic maximum derivative');jobs.append('global_gap_constant_comparison')
    # Kernel of a transitive odd-order skew matrix forces constant absolute entries.
    QQ=s.Matrix(5,5,lambda i,j:0 if i==j else 1 if i<j else -1)
    need(QQ.nullspace()==[s.Matrix([1,-1,1,-1,1])],'odd kernel');jobs.append('weighted_maximum_counterexample_kernel')
    report={'status':'PASS','independent_symbolic_groups':jobs,'scope':'Exact identities, not formal verification of analytic minimum or recovery arguments.'}
    (ROOT/'results'/'symbolic.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,sort_keys=True))
if __name__=='__main__':main()

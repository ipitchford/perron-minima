#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import combinations, permutations, product
from pathlib import Path
import random,json,sys
from core import *
ROOT=Path(__file__).resolve().parents[1]

def main():
    rng=random.Random(270927); counts={}; examples=[]
    # Original coordinate definitions; exact ordering decomposition on real skew boxes.
    total=0
    for n in range(2,11):
        for j in range(12):
            S=[[F(0)]*n for _ in range(n)]
            for i in range(n):
                for k in range(i+1,n):S[i][k]=F(rng.randint(-8,8),8);S[k][i]=-S[i][k]
            u=F([1,3,9][j%3],10*(n-1));order_certificate(S,u);total+=1
    counts['rational_skew_ordering_cases']=total
    # Quantitative odd-lattice strengthening, by direct exact quadratic evaluations.
    total=0
    for n in range(2,7):
        for j in range(10):
            S=tournament(n,rng.getrandbits(n*(n-1)//2));u=F(3,4*(n-1));R=resolvent(S,u)
            fm,_,_,_,_=constants(n,u);q=[F(rng.choice([-5,-3,-1,1,3,5])) for i in range(n)]
            if max(map(abs,q))==1:q[0]=F(3)
            g=4*(max(map(abs,q))/(1+u*u*(n-1)**2)-1)
            require(dot(q,mv(R,q))>=fm+g,'strengthened odd-vector bound fails');total+=1
    counts['odd_vector_strict_gap_cases']=total
    # All balanced words and all almost-regular six-point tournament score switches.
    words=0
    for n in range(4,14,2):
        for neg in combinations(range(n),n//2):
            pos=[i for i in range(n) if i not in neg]
            W=sum(abs(v-2*j) for j,v in enumerate(neg)); V=sum(abs(v-(2*j+1)) for j,v in enumerate(pos))
            require(W==V,'binary transport identity');words+=1
    counts['balanced_word_transport_cases']=words
    near=0
    for bits in range(1<<15):
        S=tournament(6,bits);r=mv(S,[F(1)]*6)
        if not all(abs(x)==1 for x in r):continue
        near+=1;W=switch(S,r);k=sum(W[i][j]==-1 for i in range(6) for j in range(i+1,6))
        neg=[i for i in range(6) if r[i]==-1];swaps=sum(abs(v-2*j) for j,v in enumerate(neg))
        require(swaps<=k,'all-near-regular repair identity')
    counts['all_nearly_regular_n6_checked']=near
    spectral=0
    for n,bs in [(4,list(range(64))),(6,[rng.getrandbits(15) for _ in range(100)]),(8,[rng.getrandbits(28) for _ in range(24)]),(10,[rng.getrandbits(45) for _ in range(12)])]:
        for b in bs:
            r=recover(tournament(n,b),F(1,n));spectral+=1
            if len(examples)<12 or (r['mode']=='nearly_regular' and r['edits_to_returned_BL']>0 and len(examples)<30):examples.append(r)
        for u in [F(1,2*n),F(3,4*n),F(1,n)]:
            r=recover(BL(n),u);require(r['edits_to_returned_BL']==0 and F(r['certified_deficit_lower'])==0,'BL equality');spectral+=1
    # Score-preserving directed-cycle switches provide nontrivial near-regular cases.
    for n in [6,8,10]:
        S=BL(n)
        for trial in range(20):
            cycles=[(i,j,k) for i,j,k in combinations(range(n),3)
                    if S[i][j]==S[j][k]==S[k][i]]
            i,j,k=rng.choice(cycles)
            for a,b in [(i,j),(j,k),(k,i)]:S[a][b]*=-1;S[b][a]*=-1
            rec=recover(S,F(1,n));spectral+=1
            if trial<2:examples.append(rec)
    counts['exact_global_recovery_cases']=spectral
    # Exact determinant witnesses: transitive spectra do not depend on vertex order.
    determinants=0
    for n in range(2,7):
        for j in range(6):
            m=[F(rng.randint(1,12),rng.randint(1,4)) for i in range(n)];gamma=[F(rng.randint(0,8),3) for i in range(n)];t=F([1,2,4][j%3],5)
            lam=max(gamma)+F(7,3);target=poly_minimum(lam,m,gamma,t)
            for pp in [list(range(n)),list(reversed(range(n))),rng.sample(range(n),n)]:
                SS=[[F(0)]*n for _ in range(n)]
                for i in range(n):
                    for k in range(n):SS[pp[i]][pp[k]]=Q(n)[i][k]
                A=weighted_matrix(m,gamma,t,SS)
                D=[[lam*F(i==k)-A[i][k] for k in range(n)] for i in range(n)]
                require(det(D)==target,'weighted product determinant identity');determinants+=1
    counts['weighted_determinant_cases']=determinants
    # Independent positive row-ratio brackets verify strict non-transitive minimum.
    weighted=0;trans=0;paramsets=[]
    for n in [4,5]:
        for j in range(2):
            m=[F(i+1 if j==0 else (i+1)**2,3) for i in range(n)]
            gamma=[F((2*i+1)%5,4) for i in range(n)];t=F(2+j,4)
            lo,hi=minimum_bracket(m,gamma,t,90);paramsets.append({'n':n,'m':list(map(str,m)),'diagonal':list(map(str,gamma)),'t':str(t),'root_interval':[str(lo),str(hi)]})
            for b in range(1<<(n*(n-1)//2)):
                S=tournament(n,b);A=weighted_matrix(m,gamma,t,S)
                degree=sorted(sum(x>0 for x in row) for row in S)
                lower,upper=perron_ratios(A)
                if degree==list(range(n)):
                    require(lower<=hi and upper>=lo,'transitive Perron witness');trans+=1
                else:
                    require(lower>hi,'non-transitive weighted Perron gap not certified')
                weighted+=1
    counts['weighted_orientation_row_ratio_certificates']=weighted;counts['weighted_transitive_equalities']=trans
    # Weighted-maximum obstruction: cyclic blocks of sizes 3,1,1.
    n=5;S=[[F(0)]*n for _ in range(n)]
    for i,j in [(0,1),(1,2),(2,0)]+[(i,3) for i in range(3)]+[(3,4)]+[(4,i) for i in range(3)]:S[i][j]=1;S[j][i]=-1
    m=list(map(F,[1,1,1,3,3]));require(mv(S,m)==[0]*5,'weighted maximum obstruction')
    for t in [F(1,5),F(1,2),F(9,10)]:
        A=weighted_matrix(m,m,t,S);require(mv(A,[F(1)]*5)==[F(9)]*5,'weighted maximum exact eigenpair')
    counts['weighted_maximum_obstruction_parameters']=3
    report={'status':'PASS','counts':counts,'weighted_examples':paramsets,'recovery_examples':examples,'scope':'Exact finite identity and inequality checks, not a formal proof of the universal theorems.'}
    (ROOT/'results'/'exact.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'PASS','counts':counts},sort_keys=True))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Manifest check and replay. Propagates optimised Python flags; no assertions."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,os
ROOT=Path(__file__).resolve().parent

def manifest():
    n=0
    for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
        h,p=line.split('  ',1);f=ROOT/p
        if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=h:raise ValueError('manifest mismatch: '+p)
        n+=1
    return n

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--full',action='store_true');ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    n0=manifest();env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    jobs=[['verify_reference.py']] if args.smoke else [['verify_reference.py'],['verify_exact.py'],['verify_symbolic.py']]+[['negative_controls.py','--part',part] for part in ['none','wrong_determinant','wrong_resolvent_gap','negative_coefficient']]
    if args.full and not args.smoke:jobs+=[['numerical_checks.py']]
    records=[]
    for job in jobs:
        f=job[0]
        print('Running '+ ' '.join(job), file=sys.stderr, flush=True)
        flags=['-OO'] if sys.flags.optimize==2 else ['-O'] if sys.flags.optimize==1 else []
        p=subprocess.run([sys.executable,*flags,'code/'+f,*job[1:]],cwd=ROOT,env=env,capture_output=True,text=True)
        if p.returncode:
            sys.stderr.write(p.stdout+p.stderr);raise RuntimeError('job failed: '+f)
        records.append({'job':job,'returncode':0,'stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest()})
    n1=manifest();report={'status':'PASS','mode':'smoke' if args.smoke else 'full' if args.full else 'default','manifested_files_before':n0,'manifested_files_after':n1,'jobs':records,'scope':'Exact finite checks and numerical corroboration, not proof-assistant verification.'}
    if not args.smoke:(ROOT/'REPLAY_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,sort_keys=True))
if __name__=='__main__':main()

# Evidence ledger

## Analytic scope

The complete proofs are in the research note. Universal dimension claims are supported by those arguments, not enumeration. The constructive spectral coefficient is not claimed sharp. No global weighted tournament maximum is proved.

## Replayed predecessor

The unmodified `tournament_envelope_v0_1.zip` was extracted and its default replay run. All three jobs passed and its 47-file manifest verified; the complete output is `logs/predecessor_default.log`. Its full-mode Bernstein enumeration and numerical searches were not regenerated. The supplied full-text audit of the 2003/2006 Levinger papers is preserved unchanged, not newly rerun here.

## New exact and symbolic checks

`results/exact.json` records the actual counts: 108 rational continuous-skew ordering cases; 50 odd-vector strict penalties; 1,272 balanced-word transport cases; every one of the 2,640 nearly regular labelled six-point tournaments; 272 rational recovery/row-ratio certificates; 90 weighted determinant cases; 2,176 weighted tournament row-ratio cases; 288 transitive equality cases; and three parameters for the weighted-maximum obstruction. These categories overlap and must not be added into a count of independent experiments.

`verify_symbolic.py` does not import the rational geometry routines. Its ten groups reconstruct identities in symbolic variables and direct low-dimensional determinants. Neither implementation is a proof assistant.

## Numerical corroboration

`results/numerical.json` retains all 30 weighted-box optimisation starts, outputs, termination status and objective discrepancies, plus four 65-digit spectral comparisons. All 30 solver calls report success in this recorded run. The maximum absolute discrepancy from the claimed minimum is below 2.14e-14. This is not a coverage probability, certified global optimisation or evidence of a theorem beyond the analytic hypotheses.

## Negative controls

Four `negative_*.json` reports partition 40 executions. Ten valid cases must pass. Each of a wrong determinant, a wrong resolvent gap and a negative purportedly positive coefficient must fail in five interpreter modes both directly and through the wrapper. Checksums in disposable copies are recomputed after mutation. The tests therefore cannot succeed solely by noticing a changed file hash.

Initial attempts to group the checks in short tool calls, including a full replay with a four-minute execution allowance, were interrupted by execution time limits, not by a mathematical counterexample. No incomplete success receipt was issued. The negative-control set was partitioned into four groups, and the complete replay was subsequently given enough execution time. Only the completed final receipt establishes full replay.

## Reproducibility and receipt

Manifest comparison after replay detects any changed substantive result bytes. Runtime durations are not stored in deterministic results. The replay receipt itself is outside the manifest and contains output hashes, job names and scope. The final fresh-extraction receipt is supplied separately with the archive.

## Nonclaims

No authenticated external specialist endorsement, exhaustive priority audit, formal verification, empirical application validation, release licence, DOI or REF classification is asserted.

# Constructive resolvent ordering and weighted Perron minima

Research draft v0.1 — 27 September 2026. This is a new proof-and-evidence supplement, not a publication release or a claim of established priority.

## Start here

- `paper/resolvent_extensions.pdf`: the complete analytic proof.
- `RESEARCH_NOTE.md`: equivalent editable mathematics; `paper/resolvent_extensions.tex` is editable typesetting source.
- `review/REVIEW_GUIDE.md`: load-bearing arguments and scope boundaries.
- `CLAIM_CHECK_MAP.md`, `EVIDENCE_LEDGER.md`, `SOURCE_LEDGER.md`: distinguish universal proof, finite checks, earlier work and missingness.

## What is proved in the draft

An exact nonnegative-summand identity gives constructive quantitative minimisation of a resolvent on the skew box. Combined with odd-score parity, it yields an all-parameter spectral-deficit-to-edge-distance bound and a labelled Brualdi–Li recovery algorithm. A second theorem classifies every local and global minimum in a continuous matrix family with arbitrary positive vertex weights and nonnegative diagonal. A product equation computes the common optimum of all transitive orientations.

The stability coefficient is not sharp. The recovered copy need not be nearest. The weighted theorem solves the minimum over the continuous skew box, not the weighted tournament maximum; an exact five-vertex example defeats a naive switched-transitive maximum conjecture.

## Reproduction

Use Python 3.11 or later. The rational diagnostic and exact verifiers use the standard library. The symbolic job needs SymPy; full numerical corroboration additionally needs NumPy, SciPy and mpmath. Installed versions are recorded in `ENVIRONMENT.json`, and pinned versions are in `requirements.txt`.

```sh
python replay.py
python replay.py --full
```

Default mode has seven jobs: the stored-identity verifier, the rational verifier, the symbolic verifier, and four separately recorded negative-control groups. Full mode adds the numerical corroboration job. Before and after, all manifested files are checked. `REPLAY_REPORT.json` is the unmanifested execution receipt. No theorem follows merely from replay success.

All proof-critical conditions use explicit exceptions, not Python assertions. The negative controls require valid inputs to pass and corrupted inputs to fail in ordinary Python, `-O`, `-OO`, and both `PYTHONOPTIMIZE` settings, directly and through the replay wrapper. The disposable manifests are recomputed after each corruption.

## Exact diagnostic examples

```sh
python code/diagnostic.py examples/weighted.json
python code/diagnostic.py examples/recover.json
```

Input decimals are not silently treated as exact mathematical rationals: use integer or fraction strings. The recovery interface accepts a rational resolvent parameter u and derives rational t and the exact comparison Perron value; it rejects t outside (0,1]. The weighted-minimum interface brackets the root with rational arithmetic. Both examples and their expected receipts are supplied.

The recovery bound is a sufficient certificate, not an exact edge-distance optimiser. The weighted feasibility result concerns only the specified factorised interaction family. No rounding theorem for arbitrary reciprocal matrices is supplied.

## Preservation and assurance

The predecessor envelope archive and its full-text literature audit are retained byte-for-byte in `provenance/`, with hashes in `PROVENANCE.json`. No third-party full-text journal PDF is redistributed. Only the predecessor's default replay was rerun here; its larger full-mode experiments are not claimed as freshly regenerated.

No specialist review, proof-assistant verification, licence assignment, DOI or website deployment is claimed. Numerical trials retain all starts and outcomes and are implementation corroboration only.

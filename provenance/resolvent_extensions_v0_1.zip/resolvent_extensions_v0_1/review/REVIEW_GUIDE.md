# Reviewer’s guide

**Constructive resolvent ordering and weighted Perron minima — research v0.1**

## What merits review

The candidate has two new targets: a constructive edit-distance consequence of the full-path Brualdi–Li theorem, and an exact global minimum principle for heterogeneous positive matrices. The second is independent of tournament parity; the first reproves the predecessor’s comparison using its parity argument and a different ordering identity. Historical novelty remains unestablished.

## Load-bearing arguments

**Ordering (Section 2).** Check the orientation of the resolvent identity and why sorting the positive *right* vector makes every paired summand nonnegative. The lower bound for the smallest vector entry is derived from the norm identity, not a false claim that the whole inverse is nonnegative.

**Parity and recovery (Sections 3–4).** Check the $\pm2$ lattice move, the explicit score-exclusion constant, and the stable binary-word transport identity. Recovery outputs a labelled Brualdi–Li matrix but does not solve minimum edit distance. The coefficient is deliberately loose; positivity is strict at every allowed parameter.

**Weighted local minima (Section 5.1).** At a spectral critical point of a single skew entry, verify the implicit derivative sign using f_lambda < 0 and the positive symmetric part of the accretive inverse. A zero first derivative is incompatible with a local minimum, even at a one-sided endpoint. No global spectral convexity is assumed.

**Cospectrality and scalar root (Section 5.2).** Check the even-minor determinant calculation and rank-one update. Every transitive order has the same polynomial in the prescribed weight/diagonal pairs; this is stronger than permutation invariance with simultaneous movement of those data. Root uniqueness is proved only above the largest diagonal, where positivity holds.

## Explicit boundaries

The heterogeneous theorem requires positive weights, nonnegative diagonal, $n\ge2$ and $0<t<1$. Extra equality configurations can appear at t = 1. Its continuous maximum is the classical symmetric-part bound, not a new weighted tournament maximum. The five-vertex counterexample is included to prevent that extrapolation. The stabilisation corollary concerns a specific factorised positive system, not general network design.

The scripts check algebra and finite instances; the paper supplies the universal arguments. A fresh replay is not authenticated independent review. Older arc-reversal papers and the full published Drury argument remain important priority checks.

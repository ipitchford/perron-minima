# Source and prior-art ledger

**Search/check date:** 27 September 2026. **Scope:** this new supplement’s ordering, stability and heterogeneous-minimum claims. English-language web and primary-source lookups; not a systematic MathSciNet or zbMATH review.

## Supplied materials used

The predecessor full-path note was read in full through Files. The complete 2003 and 2006 Psarrakos–Tsatsomeros texts are provided in the conversation and were inspected in the preceding full-text audit. Their rank-one setting, projection identities, Levinger derivative bounds and variance-based tournament comparisons are established background. Their PDF files are not redistributed in this supplement. The earlier audit is preserved unchanged.

## Public primary sources inspected

- Drury’s author exposition: https://www.math.mcgill.ca/drury/research/brualdili/ . Read for the classical endpoint and characteristic-polynomial approach. Drury’s full published 2012 proof was not retrieved or audited here.
- Altenberg and Cohen: https://arxiv.org/abs/2007.02618 . Abstract and journal metadata directly checked; search-retrieved full-text passages consulted for the nonconcavity warning. Journal reference: LAA 606 (2020), 201–218, DOI 10.1016/j.laa.2020.07.028. Not a premise of our proof; cited to exclude an unjustified concavity assumption.

## Search targets

Four enriched Exa query families asked specifically about: (1) transitive minimum along Levinger paths with unequal weights; (2) fixed diagonal plus factorised rank-one off-diagonal interaction and the proposed product equation; (3) spectral-deficit/edge-edit Brualdi–Li stability; (4) local-minimum classification and transitive cospectrality. Native web access checked the two primary pages above. No directly matching all-weight/all-diagonal minimum or constructive edit-distance theorem was found.

## Closest unresolved comparisons

Searches surfaced Kirkland’s 1995 work on spectral radii under an arc reversal, the 1996 minimum for irreducible tournament matrices, Gregory–Kirkland’s singular-value extremisers and fixed-Frobenius perturbation bounds. Their abstracts/snippets concern related but different domains or objectives. Those full texts were not all read, so this is not a priority clearance. In particular, optimal-orientation and fixed-pair-sum matrix literature needs further specialist comparison.

## Claim ownership

- Rank-one/diagonal-plus-rank-one decompositions, Perron derivatives, the resolvent identity, rank-one determinant updates and symmetric-part upper bounds: classical tools.
- The odd-lattice reduction and qualitative full-path Brualdi–Li maximum: inherited from the supplied candidate and reproved as needed; its endpoint is Drury’s established theorem.
- Exact sorted-resolvent sum identity, the explicit all-parameter recovery bound, and the heterogeneous minimum/landscape classification: derived in this supplement; no exact predecessor found within this bounded search. Historical novelty remains unestablished.
- No absence-of-search-result claim is used as a mathematical premise or as proof of originality.
